﻿SiSL's Mega Pack feat. Star Wars DLC
------------------------------------------------

Version: 1.3

FACEBOOK PAGE: https://www.facebook.com/sislsmegapack/
Like and make sure to subscribe on Facebook page to see all items and upcoming features in next release.

EN: This package adds many cabin accessories and only runs with Cabin Accessories DLC.
TR: Bu paket kabin içi aksesuar ekler ve Cabin Accessories DLC olmadan çalışmaz. 

VIDEO: https://youtu.be/Uxx5w60F2Ok
DOWNLOAD: http://adf.ly/1Qrq85

FORUM/REQUESTS/BUGS: http://forum.scssoft.com/viewtopic.php?t=194010

Please respect original download link. If you have downloaded from anywhere except this link, it may be broken or can have security issue. please inform the site about respecting original link. You can also follow new versions and updates from the topic above.

Co-Drivers: Yasemin, Ilhami and Melissa, Ayça, Ozan, Darth Vader

Waters, Soda cans, Coffee mugs, Amulets, Car Freshners, Dream catcher, Soccer balls, Documents and many more with all animations where possible...

Also featuring Star Wars Pack 

C3PO as your co-driver, enjoy R2-D2 as your guide. Stormtrooper, Yoda and C3PO Bobbleheads, Lightsabers, Darth Vader, Stormtrooper, Bobba Fett and Endor Helmets including YT-1300 (Millenium Falcon) , X-Wing, TIE Fighter toys.

Important Note: To make the pack in English, please move addon on "top" of original mod. You should use two files together on your mod list.

TR: Bu paket bir çok Türkiye'ye özel nesne içerse de, asıl olarak kabin içinde kullanılabilecek bir çok objeyi bir araya getiren bir pakettir. 


HISTORY


v1.3 - 16.12.2015 - The Force Awakens

- Change Vaultboy and fixed size to be in-par with other boobleheads
- Fixed Stormtrooper, Yoda and C3PO Bobblehead, Ben Kenobi textures
- Fixed Ajanda/Journal shadows
- Fixed BB-8 Droid materials
- Fixed Cleaning Kit materials
- Fixed many materials to be inline with OpenGL


  Additions:
	- Passport (Customizable, details in Facebook page)
	- Big Flag updated to be customizable
	- Smeagol (due to court order)
	- Wall-E toy
	- EV toy
	- Backpack 
	- Another Sports Bag
	- DAF XF Euro 6 Die-Cast Toy
	- Toilet Papers
	- Dash cam for hang slot
	- Sleeping Bag
	- Pokemon Additions both dash & seat
		- Pokemon Ball
		- Absol
		- Glaceon
		- Pikachu
		- Eevee
		- Porygon
		- Leafeon
	- Angry Birds, Red, Bomb, Chuck and a Pig Minion 



  STAR WARS Additions:
	- Jabba the Hutt Figurine
	- Boba Fett Figurine
	- 6x Star Wars Franchise Mugs
	- AT-ST (All Terrain Scout Transport)
	- AT-AT (All Terrain Armored Transport)
	- Slave I (Boba Fett's ship)




v1.2.2 - 02.12.2015
- Fixed objects for a problem that causes crash on OpenGL
- Fixed missing UI
- Fixed some spelling errors
- Knitbasket also to seat
- Fixed Briefcase
- Fixed Poppy's Jasmine to be opaque as original




v1.2 - 30.11.2015

- Fixed Crowbar shadows
- Fixed dark UI images
- Fixed CD materials

- New additions:
  - Baseball bat
  - Die-cast Skinnable Replicas (credits: SCS, see Customization.scs file for skins):
     - Iveco Hi-way
     - Scania Streamline
     - Volvo FH16
     - Renault Magnum
     - Mercedes Actros 2009
     - DAF XF
     - MAN TGX
  - Golf ball
  - Dalek Toy (Doctor Who)
  - 4x Double Dices
  - HiVis RainCoat
  - Changed Garfield expression on the glass for better fitting where he is, but also new Garfield added for stand.
  - Fallout Vault Boy Bobblehead
  - Knitting basket (credits to Jokerine)
  - 9x Poppy's Fresheners
  - Xmas Trees (Big animated and Dashboard versions)
  - Taz Toy
  - Tool box
  - Turkish Insignia
  - Mini Wind Turbine Toy
  - Backgammon & Checkers Board
  - Trophy Cup
  - Snacks 


  STAR WARS Additions:
  - X-Wing S-Foil Open Hang Toy
  - TIE Fighter Hang Toy
  - Darth Vader as Co-Driver
  - YT-1300 Millenium Falcon Hang Toy
  - Jedi Star Fighter
  - Lambda Shuttle Hang Toy
  - Star Destroyer Hang Toy
  - Rebel Insignia Hang Toy
  - Imperial Insignia Hang Toy



v1.1.4 - 09.11.2015
- Refixed codrivers for modded trucks and UK variants of both SCS and modded trucks
- Fixed Odie's shadow
- Fixed Normals on UK variant of C3PO
- Fixed Big Turkish flag with correct rope

v1.1 - 08.11.2015 
- Fixed Galaxy S2 model and many other small fixes.
- Additions: 
  - Dog Tags
  - 2 Bobblehead Kittens
  - Garfield
  - Odie
  - Cowboy Hat
  - TARDIS
  - BB-8 Droid (Star Wars: Force Awakens)
  - Pencil Case
  - Leather Briefcase
  - Cleaning Kit (Microfiber cloth & Spray)
  - 5 different picture frames customizable (see customization section)
  - Medicines
  - First Aid Kit
  - Coin & Note Change
  - Portable Torch
  - UK variants of Codrivers, (see: http://forum.scssoft.com/viewtopic.php?p=462284#p462284)
  
  New Codrivers:
  - Ayça
  - Ozan
  - Ben Kenobi


v1.0.1 - 01.11.2015 
- Small update to include Volvo VNL (no other changes) 

v1.0 - 01.11.2015 
- Initial release
